document.getElementById("bloqueo").hidden="true";
document.getElementById("containerdibuja").hidden="true";

var bandera= false;
var cont=0;
var sigCanvas;
function activadibuja()
{ 
	document.getElementById("bloqueo").hidden="true";
	//document.getElementById("containerdibuja").hidden="";
	$("#contenido").prepend($( "#containerdibuja" ));
	$( "#containerdibuja" ).show("blind")
	if(cont==0){
		bandera=true;
		initialize();
		cont=10;
	}
	else{ bandera=true; }
}


function desactivadibuja()
{
	document.getElementById("bloqueo").hidden="";
	// document.getElementById("containerdibuja").hidden="true";
	$( "#containerdibuja" ).fadeOut();
	bandera=false;
	if (sigCanvas && sigCanvas != null)
		$(sigCanvas).unbind("initialize();");
}

function loadCanvas(dataURL) {
	var canvas = document.getElementById('canvasSignature');
	var context = canvas.getContext('2d');

	// load image from data url
	var imageObj = new Image();
	imageObj.onload = function() {
		context.drawImage(this, 0, 0);
	};

	imageObj.src = dataURL;
}

function get_dibujo() {
	var canvas = document.getElementById('canvasSignature');
	return canvas.toDataURL();
}

window.context=2;
var background = false;
var borrar = false;
var canvasatras = document.getElementById("canvasatras");
var ctx = canvasatras.getContext("2d");
$(document).ready(function () {
	$('#lapiz').click(dibujando);
	$('#goma').click(borrando);
	$('#limpia').click(eliminar);
});
function eliminar(){
	//alert("eliminar");
	console.log("eliminar");
	window.context.clearRect(0,0,322,414);
	ctx.clearRect(0,0,322,414);
	background = false;
}
var contborrar=0;
function borrando(){
	//alert("borrando");
	console.log("borrando");
	if(contborrar==0)
	{
		borrar = !borrar;
		contborrar=1;
	}
}
function dibujando(){
	//alert("eliminar");
	console.log("dibujando");
	if(contborrar==1)
	{
		borrar = !borrar;
		contborrar=0;
	}
}

function getPosition(mouseEvent, sigCanvas) {
	var x, y;
	if (mouseEvent.pageX != undefined && mouseEvent.pageY != undefined) {
		x = mouseEvent.pageX;
		y = mouseEvent.pageY;
	} else {
		x = mouseEvent.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
		y = mouseEvent.clientY + document.body.scrollTop + document.documentElement.scrollTop;
	}
	return { X: x - sigCanvas.offsetLeft, Y: y - sigCanvas.offsetTop };
}

function initialize() {

	//-------------------------------------------------

	sigCanvas = document.getElementById("canvasSignature");
	window.context = sigCanvas.getContext("2d");
	window.context.strokeStyle = '#000000';
	window.context.lineWidth = 2;

	var is_touch_device = 'ontouchstart' in document.documentElement;

	// if (is_touch_device) {
	// 	var drawer = {
	// 		isDrawing: false,
	// 		touchstart: function (coors) {
	// 			console.log("touchstart");
	// 			window.context.beginPath();
	// 			window.context.moveTo(coors.x, coors.y);
	// 			this.isDrawing = true;
	// 		},
	// 		//--------
	// 		touchmove: function (coors) {
	// 			console.log("touchmove");
	// 			if (this.isDrawing) {
	// 				console.log("touchisdrawing");
	// 				if(borrar){
	// 					window.context.clearRect(coors.x,coors.y,10,10);					
	// 				}
	// 				else{
	// 					window.context.lineTo(coors.x, coors.y);
	// 					window.context.stroke();
	// 				}
	// 			}
	// 		},
	// 		//-------
	// 		touchend: function (coors) {
	// 			console.log("touchend");
	// 			if (this.isDrawing) {
	// 				this.touchmove(coors);
	// 				this.isDrawing = false;
	// 			}
	// 		}
	// 	};



	// 	function draw(event) {

	// 		var coors = {
	// 			x: event.targetTouches[0].pageX,
	// 			y: event.targetTouches[0].pageY
	// 		};

	// 		var obj = sigCanvas;

	// 		if (obj.offsetParent) {
	// 			do {
	// 				coors.x -= obj.offsetLeft;
	// 				coors.y -= obj.offsetTop;
	// 			} while ((obj = obj.offsetParent) != null);
	// 		}

	// 		drawer[event.type](coors);
	// 	};

	// 	sigCanvas.addEventListener('touchstart', draw, false);
	// 	sigCanvas.addEventListener('touchmove', draw, false);
	// 	sigCanvas.addEventListener('touchend', draw, false);
	// 	sigCanvas.addEventListener('touchmove', function (event) {
	// 		event.preventDefault();
	// 	}, false);

	// }
	// else {

		$("#canvasSignature").click(function (mouseEvent) {
			var position = getPosition(mouseEvent, sigCanvas);
			console.log("mousedown");
			window.context.moveTo(position.X, position.Y);
			window.context.beginPath();

			$(this).mousemove(function (mouseEvent) {
				console.log("mousemove");
				drawLine(mouseEvent, sigCanvas, window.context);
			}).mouseup(function (mouseEvent) {
				console.log("mouseup");
				finishDrawing(mouseEvent, sigCanvas, window.context);
			}).mouseout(function (mouseEvent) {
				console.log("mouseout");
				finishDrawing(mouseEvent, sigCanvas, window.context);
			});
		});
	// }


}
//-----------------------------------------------------

function drawLine(mouseEvent, sigCanvas) {
	if(bandera){
		var position = getPosition(mouseEvent, sigCanvas);
		if(borrar){
			window.context.clearRect(position.X,position.Y,20,20);					
		}
		else{
			window.context.lineTo(position.X, position.Y);
			window.context.stroke();
		}
	}
}
function finishDrawing(mouseEvent, sigCanvas) {
	if(bandera){   
		drawLine(mouseEvent, sigCanvas, window.context);
		window.context.closePath();

		$("#canvasSignature").unbind("mousemove")
		.unbind("mouseup")
		.unbind("mouseout");
	}
}
function get_dibuja() {
	return sigCanvas.toDataURL();
}
function carga_dibuja(data){
	loadCanvas(data);
}