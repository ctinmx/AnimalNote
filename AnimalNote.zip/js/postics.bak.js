document.getElementById("containerpostics").hidden="true";
	 function activapostics()
		{ 
			document.getElementById("containerpostics").hidden="";
		}


		function desactivapostics()
		{
			document.getElementById("containerpostics").hidden="true";
		}

$(function() {
$( "#item1" ).draggable();
});

$(function() {
$( "#item2" ).draggable();
});

$(function() {
$( "#item3" ).draggable();
});

$(function() {
$( "#item4" ).draggable();
});

$(function() {
$( "#item5" ).draggable();
});

$(function() {
$( "#item6" ).draggable();
});

$(function() {
$( "#item7" ).draggable();
});

$(function() {
$( "#item8" ).draggable();
});

$(function() {
$( "#item9" ).draggable();
});

$(function() {
$( "#item10" ).draggable();
});

$(function() {
$( "#item11" ).draggable();
});

$(function() {
$( "#item12" ).draggable();
});

$(function() {
$( "#item13" ).draggable();
});

$(function() {
$( "#item14" ).draggable();
});

$(function() {
$( "#item15" ).draggable();
});

$(function() {
$( "#item16" ).draggable();
});

$(function() {
$( "#item17" ).draggable();
});

$(function() {
$( "#item18" ).draggable();
});

$(function() {
$( "#item19" ).draggable();
});

$(function() {
$( "#item110" ).draggable();
});

$(function() {
$( "#item21" ).draggable();
});

$(function() {
$( "#item22" ).draggable();
});

$(function() {
$( "#item23" ).draggable();
});

$(function() {
$( "#item24" ).draggable();
});

$(function() {
$( "#item25" ).draggable();
});

$(function() {
$( "#item26" ).draggable();
});

$(function() {
$( "#item27" ).draggable();
});

$(function() {
$( "#item28" ).draggable();
});

$(function() {
$( "#item29" ).draggable();
});

$(function() {
$( "#item210" ).draggable();
});

$(function() {
$( "#item31" ).draggable();
});

$(function() {
$( "#item32" ).draggable();
});

$(function() {
$( "#item33" ).draggable();
});

$(function() {
$( "#item34" ).draggable();
});

$(function() {
$( "#item35" ).draggable();
});

$(function() {
$( "#item36" ).draggable();
});

$(function() {
$( "#item37" ).draggable();
});

$(function() {
$( "#item38" ).draggable();
});

$(function() {
$( "#item39" ).draggable();
});

$(function() {
$( "#item310" ).draggable();
});

$(function() {
$( "#item41" ).draggable();
});

$(function() {
$( "#item42" ).draggable();
});

$(function() {
$( "#item43" ).draggable();
});

$(function() {
$( "#item44" ).draggable();
});

$(function() {
$( "#item45" ).draggable();
});

$(function() {
$( "#item46" ).draggable();
});

$(function() {
$( "#item47" ).draggable();
});

$(function() {
$( "#item48" ).draggable();
});

$(function() {
$( "#item49" ).draggable();
});

$(function() {
$( "#item410" ).draggable();
});

$(function() {
$( "#item51" ).draggable();
});

$(function() {
$( "#item52" ).draggable();
});

$(function() {
$( "#item53" ).draggable();
});

$(function() {
$( "#item54" ).draggable();
});

$(function() {
$( "#item55" ).draggable();
});

$(function() {
$( "#item56" ).draggable();
});

$(function() {
$( "#item57" ).draggable();
});

$(function() {
$( "#item58" ).draggable();
});

$(function() {
$( "#item59" ).draggable();
});

$(function() {
$( "#item510" ).draggable();
});

$(function() {
$( "#item61" ).draggable();
});

$(function() {
$( "#item62" ).draggable();
});

$(function() {
$( "#item63" ).draggable();
});

$(function() {
$( "#item64" ).draggable();
});

$(function() {
$( "#item65" ).draggable();
});

$(function() {
$( "#item66" ).draggable();
});

$(function() {
$( "#item67" ).draggable();
});

$(function() {
$( "#item68" ).draggable();
});

$(function() {
$( "#item69" ).draggable();
});

$(function() {
$( "#item610" ).draggable();
});

$(function() {
$( "#item71" ).draggable();
});

$(function() {
$( "#item72" ).draggable();
});

$(function() {
$( "#item73" ).draggable();
});

$(function() {
$( "#item74" ).draggable();
});

$(function() {
$( "#item75" ).draggable();
});

$(function() {
$( "#item76" ).draggable();
});

$(function() {
$( "#item77" ).draggable();
});

$(function() {
$( "#item78" ).draggable();
});

$(function() {
$( "#item79" ).draggable();
});

$(function() {
$( "#item710" ).draggable();
});

$(function() {
$( "#item81" ).draggable();
});

$(function() {
$( "#item82" ).draggable();
});

$(function() {
$( "#item83" ).draggable();
});

$(function() {
$( "#item84" ).draggable();
});

$(function() {
$( "#item85" ).draggable();
});

$(function() {
$( "#item86" ).draggable();
});

$(function() {
$( "#item87" ).draggable();
});

$(function() {
$( "#item88" ).draggable();
});

$(function() {
$( "#item89" ).draggable();
});

$(function() {
$( "#item810" ).draggable();
});

$(function() {
$( "#item91" ).draggable();
});

$(function() {
$( "#item92" ).draggable();
});

$(function() {
$( "#item93" ).draggable();
});

$(function() {
$( "#item94" ).draggable();
});

$(function() {
$( "#item95" ).draggable();
});

$(function() {
$( "#item96" ).draggable();
});

$(function() {
$( "#item97" ).draggable();
});

$(function() {
$( "#item98" ).draggable();
});

$(function() {
$( "#item99" ).draggable();
});

$(function() {
$( "#item910" ).draggable();
});

$(function() {
$( "#item101" ).draggable();
});

$(function() {
$( "#item102" ).draggable();
});

$(function() {
$( "#item103" ).draggable();
});

$(function() {
$( "#item104" ).draggable();
});

$(function() {
$( "#item105" ).draggable();
});

$(function() {
$( "#item106" ).draggable();
});

$(function() {
$( "#item107" ).draggable();
});

$(function() {
$( "#item108" ).draggable();
});

$(function() {
$( "#item109" ).draggable();
});

$(function() {
$( "#item1010" ).draggable();
});
